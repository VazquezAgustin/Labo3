# Como entendi el ejercicio
Dos posibles candidatos 
PRESIDENTES
- Senor MS
- Senor MI

VICEPRESIDENTE
- Senor A
- Senor V

2 PROCESOS
- proceso PANEL
- proceso VOTANTES

VOTANTES ingresas votos
PANEL muestra lo que ingresaste por votantes

# Como ejecutar

make
./1panel
./2votantes