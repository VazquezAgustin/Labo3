#ifndef _MEMORIA
#define _MEMORIA

#define CANTIDAD 150

void* creo_memoria(int size, int* r_id_memoria, int clave_base);

#endif
