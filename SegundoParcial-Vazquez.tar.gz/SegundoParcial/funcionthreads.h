#ifndef _FUNCIONESTHREADS
#define _FUNCIONESTHREADS
#include "global.h"

void *funcionThread(void*);

#endif
