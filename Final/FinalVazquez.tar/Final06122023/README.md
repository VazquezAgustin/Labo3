
              /---> ProducirA
Genera pedido -----> ProducirB
              \----> ProducirC

Estructura de pedidos
    Menu
    Postre
    Precio

Productores debe
- Correr cada 100ms
- Mostrar
    - Total menus realizados (cantidad o menu entero?)

INSTRUCCIONES para ejecutar el programa
- make
- ./main1
- ./productor a
- ./productor b
- ./productor c