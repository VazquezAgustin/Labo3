#ifndef _FUNCIONESTHREADS
#define _FUNCIONESTHREADS
#include "global.h"

void *funcionThreadNormal(void*);
void *funcionThreadLluvia(void*);

#endif
