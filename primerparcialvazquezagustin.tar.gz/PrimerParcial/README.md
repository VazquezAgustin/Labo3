
INSTRUCCIONES PARA CORRER
- make
- ./main1
- ./alumno 1 
- ./alumno 2